jQuery( document ).ready(function($) {

    $(document).on('click','#j-max_pdf',function(){

             //on focus
                jQuery("#visa_order_form .isrequired, #visa_order_form .isrequired").focus(function(){
                    jQuery(this).removeClass('error');
                });
                
                //on blur
                jQuery("#visa_order_form .isrequired, #visa_order_form .isrequired").blur(function()
                {
                    if(jQuery(this).val() == '')
                    {
                        jQuery(this).addClass('error');
                    } else {
                        jQuery(this).removeClass('error');
                    }
                }); 
                
                if(jQuery("#title").val() == '' || jQuery("#fname").val() == '' || jQuery("#lname").val() == '' || jQuery("#country").val() == '' || jQuery("#dob").val() == '' || jQuery("#pid").val() == '' || jQuery("#ped").val() == '' || jQuery("#passport_no").val() == '' ){
            

                        jQuery("#notic_book_visa.alert").show();
                        jQuery("#notic_book_visa.alert").addClass("alert-danger");
                        jQuery("#notic_book_visa.alert").html("Please fill all mandatory fields"); 
                        
                        jQuery("#visa_order_form .isrequired" ).each(function() {   
                            filedValue = jQuery(this).val();
                            if(filedValue == '')
                            {
                                jQuery(this).addClass('error');
                            } else {
                                jQuery(this).removeClass('error');
                            }

                        });

                        jQuery("#mobile").on("keypress keyup blur",function (event) {    
                            jQuery(this).val($(this).val().replace(/[^\d].+/, ""));
                            if ((event.which < 48 || event.which > 57)) {
                                event.preventDefault();
                            }
                            jQuery(this).addClass('error');
                        });
                
                }else if (!ValidateEmail(jQuery("#email").val())) {
                    
                        jQuery("#notic_book_visa.alert").show();
                        jQuery("#notic_book_visa.alert").addClass("alert-danger");
                        jQuery("#notic_book_visa.alert").html("Please enter valid email address");
                        jQuery("#email").addClass('error');
                
                }else {

                    var formData = jQuery("#visa_order_form").serialize();
                    jQuery.ajax({                     
                        type   : "POST",
                        url    : jmax.d_pdf,            
                        data   : { data: formData,action : 'make_pdf_order' },
                        success: function(data){
                            //console.log(data);
                            window.open(jmax.p_url+data, '_blank');
                          }
                    });
                            
                    return false;
                    }


    });

});


function ValidateEmail(email) {
    var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    return expr.test(email);
};
