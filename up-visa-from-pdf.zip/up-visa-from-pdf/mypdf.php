<?php
require('\jamx\fpdf.php'); 


class PDF extends Fpdf
{
    // Page header
    function Header()
    {
        // Logo
        //$this->Image('logo.png');
        $this->Image('jamx/images/logo.png');

    }

    // Page footer
    function Footer()
    {
        
        
       
        // Position at 1.5 cm from bottom
        //$this->SetY(-15);
        //$this->setFillColor(41,87,164); 
        //$this->Cell(0,20,"",2,20,'L',1); //your cell

        // Arial italic 8
        $this->SetFont('Arial','I',8);
        // Page number
        //$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }

    
}


$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
//
//$pdf->SetFont('Arial','',10);
// Move to 8 cm to the right
//$pdf->Cell(80);


$params = array();
parse_str($_REQUEST['data'], $params);


// Insert a logo in the top-left corner at 300 dpi
//$pdf->Image('logo.png');
// background image 
$pdf->Image('jamx/images/bg.png', 0, 170);

$pdf->Ln(); //Go to a new line

$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(55,52,53);
$pdf->Cell(0,10,'Date: '.$params['currentdate'].' ',0,0,'R');
$pdf->Ln(); //Go to a new line

//OFFICIAL INVITATION Text
$pdf->SetFont('Arial','B',12);
$pdf->Cell(80);
$pdf->SetTextColor(41,87,164);
$pdf->Cell(20,10,'OFFICIAL INVITATION',0,0);
$pdf->Ln(); //Go to a new line

//text
$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(55,52,53);
$pdf->Cell(10,15,'To whom it may concern:',0,0,'L');
$pdf->Ln(); //Go to a new line

$pdf->Cell(0,0,'The Indian Radiological and Imaging Associations organizing the "73rd Annual Conference of Radiological and Imaging',0,0,'L');
$pdf->Ln(); //Go to a new line
$pdf->Cell(0,12,'Association-lRIA 2020 scheduled on January 23rd - 26th, 2020 at Mahatma Mandir Convention and Exhibition Centre,',0,0,'L');
$pdf->Ln(); //Go to a new line
$pdf->Cell(0,0,'Gandhinagar.',0,0,'L');
$pdf->Ln(); //Go to a new line

$pdf->Cell(0,15,'We are delighted to formally invite the person named below to attend the "IRIA 2020"',0,0,'L');
$pdf->Ln(); //Go to a new line

$pdf->SetFont('Arial','',10);
$pdf->SetTextColor(55,52,53);
//$pdf->Cell(50,10,"TITLE:",1,0);
// Centered text in a framed 50*10 mm cell and line break
//$pdf->Cell(50,10,$params['title'],1,0,'L');
//$pdf->Ln(); //Go to a new line

$pdf->Cell(35,7,"First Name:",0,0);
$pdf->Cell(50,7,$params['fname'],0,0,'L');

$pdf->Cell(35,7,"Last Name:",0,0);
$pdf->Cell(50,7,$params['lname'],0,0,'L');
$pdf->Ln(); 

$pdf->Cell(35,7,"Country of Origin:",0,0);
$pdf->Cell(50,7,$params['country'],0,0,'L');

$pdf->Cell(35,7,"Date of Birth:",0,0);
$pdf->Cell(50,7,$params['dob'],0,0,'L');
$pdf->Ln();

$pdf->Cell(35,7,"Passport Issue Date:",0,0);
$pdf->Cell(50,7,$params['pid'],0,0,'L');

$pdf->Cell(35,7,"Passport Expiry Date:",0,0);
$pdf->Cell(50,7,$params['ped'],0,0,'L');
$pdf->Ln();

$pdf->Cell(35,7,"Passport No:",0,0);
$pdf->Cell(50,7,$params['passport_no'],0,0,'L');

$pdf->Cell(35,7,"Email:",0,0);
$pdf->Cell(70,7,$params['email'],0,0,'L');
$pdf->Ln();

$pdf->Cell(35,7,"Mobile No:",0,0);
$pdf->Cell(50,7,$params['mobile'],0,0,'L');
$pdf->Ln(); //Go to a new line
$pdf->Ln(); //Go to a new line

$pdf->Cell(0,0,'Please note that the sole purpose of this letter is to assist the above delegate in obtaining a visa for entering in India ',0,0);
$pdf->Ln(); //Go to a new line
$pdf->Cell(0,12,'and contribute to the IRIA 2020. The letter is not and cannot be regarded as a financial commitmentfrom the IRIA 2020,',0,0);
$pdf->Ln(); //Go to a new line
$pdf->Cell(0,0,'Gandhinagar',0,0);
$pdf->Ln(); //Go to a new line
$pdf->Cell(0,15,'The purpose of this visit to Gandhinagar, India is to attend the IRIA 2020',0,0);
$pdf->Ln(); //Go to a new line
$pdf->Cell(0,7,'All lRIA 2020 related expenses are the full responsibility of the participant and we would be honored with her/his ',0,0);
$pdf->Ln(); //Go to a new line
$pdf->Cell(0,0,'presence at this event.',0,0);
$pdf->Ln(); //Go to a new line

$pdf->Cell(0,15,'Yours sincerely,',0,0);
$pdf->Ln(); //Go to a new line
//$pdf->Image('sign.png', 5, 70, 33.78);
$pdf->Image('jamx/images/sign2.png');

$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(55,52,53);
$pdf->Cell(0,10,'Or. Hemant Patel',0,0,'L');
$pdf->Ln(); //Go to a new line
$pdf->Cell(10,0,'Organizing Secretary IRIA 2020.',0,0,'L');
$pdf->Ln(); //Go to a new line

$path = "PDF/";
$rand = rand(1,1000000);
$filename = $params['fname'].'_'.$rand.'.pdf';

$pdf->Output($path.$filename, 'F');
echo $filename;


?>