<?php
/**
 * Plugin Name: UP Visa From PDF
 * Plugin URI: 
 * Text Domain: wp-visa-from-pdf
 * Description: A quick, easy way to add fill data and genrate pdf file and use shortcode [up_visa]. Also work with Gutenberg shortcode block. 
 * Author: CodeZeros
 * Version: 2.0.2
 * Author URI: https://www.codezeros.com/
 *
 * @package WordPress
 * @author CodeZeros
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Basic plugin definitions
 * 
 * @package WP Responsive Recent Post Slider
 * @since 1.0.0
 */
if( !defined( 'WPRPS_VERSION' ) ) {
	define( 'WPRPS_VERSION', '2.0.2' ); // Version of plugin
}
if( !defined( 'WPRPS_DIR' ) ) {
	define( 'WPRPS_DIR', dirname( __FILE__ ) ); // Plugin dir
}
if( !defined( 'WPRPS_URL' ) ) {
	define( 'WPRPS_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}

register_activation_hook( __FILE__, 'wprps_install' );
function wprps_install() {
	//if( is_plugin_active('up-visa-from-pdf/wp-visa-from-pdf.php') ) {
		//add_action('update_option_active_plugins', 'wprps_deactivate_version');
	//}
}

function wprps_deactivate_version() {
   //	deactivate_plugins('up-visa-from-pdf/wp-visa-from-pdf.php',true);
}

function wprps_css_script() {
	wp_enqueue_style( 'stylevisa',  plugin_dir_url( __FILE__ ). 'assets/css/stylevisa.css', array(), WPRPS_VERSION );
	wp_enqueue_script( 'visa-public-js',  plugin_dir_url( __FILE__ ). 'assets/js/up-visa-public.js', array('jquery'), WPRPS_VERSION, false );
	wp_enqueue_style( 'up-bootstrap', plugin_dir_url( __FILE__ ) . 'assets/css/bootstrap.min.css', array( ), WPRPS_VERSION);
	//wp_enqueue_script( 'up-visa-public', plugin_dir_url( __FILE__ ) . 'assets/js/up-visa-public.js', array( ), WPRPS_VERSION);
	$data = array('ajaxurl'=> admin_url('admin-ajax.php'),'d_pdf'=> WPRPS_URL.'/mypdf.php','p_url'=>plugin_dir_url( __FILE__ ).'PDF/');
	wp_localize_script( 'visa-public-js', 'jmax', $data);
	

}
add_action( 'wp_enqueue_scripts', 'wprps_css_script' );


add_action('wp_ajax_make_pdf_order', 'make_pdf_order_fun');
add_action('wp_ajax_nopriv_make_pdf_order', 'make_pdf_order_fun');

function make_pdf_order_fun(){
	$data_ans = $_REQUEST["data"];
	print_r($data_ans);
	exit();
}

// Shortcodes
require_once( '/includes/up-visafrm-shortcodes.php' );
