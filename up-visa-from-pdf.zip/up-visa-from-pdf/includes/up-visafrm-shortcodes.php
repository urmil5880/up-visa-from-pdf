<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;	// Exit if accessed directly
}

function wpnaw_get_pdffrm( $atts ){
	//echo WPRPS_DIR.'/mypdf.php';
	 ob_start();		
	?>
	<div class="upvisa-pdf visa-clearfix">
		<div class="panel-body" >
		    <?php include('pdf-form.php');?>
		</div>
	</div>
	<?php	
	$out = ob_get_clean();	
	return $out;
}
// 'up_visa' shortcode
add_shortcode('up_visa','wpnaw_get_pdffrm');

?>
